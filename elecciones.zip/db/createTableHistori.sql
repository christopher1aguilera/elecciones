CREATE TABLE historial (estado varchar ( 35 ) UNIQUE , votos INT , ganador
varchar ( 40 ));