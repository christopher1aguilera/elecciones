CREATE TABLE candidatos ( id SERIAL , nombre VARCHAR ( 50 ), foto
varchar ( 200 ), color varchar ( 9 ), votos INT );